<?php

setcookie('name',null);
setcookie('email',null);
header('location:index.php');