<footer class="footer-area">
        This is footer
    </footer>
</body>
</html>