<?php include_once('header.php'); ?>

<div class="content">
    <pre>
        This is our content.
        This is our content.
        This is our content.
        This is our content.
        This is our content.
        This is our content.
    </pre>

</div>

<?php include('footer.php'); ?>