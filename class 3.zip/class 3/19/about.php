<?php
$title="about";
require('header.php');
?>
<div class="content">
    This is about page
</div>
<?php require_once('footer.php');?>