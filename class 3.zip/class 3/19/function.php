<?php
function title(){
    global $title;
    echo  $title;
}