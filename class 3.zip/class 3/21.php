<?php
//parse/syntax error
echo "parse/ syntax error;

//fatal error
echo z();

//warning error
include("z.php");

//notice error
echo $z;