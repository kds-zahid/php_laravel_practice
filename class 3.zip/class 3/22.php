<?php
if(true){
    throw new Exception("___Error_if_condition_is_true___");
}else{
    throw new Exception("___Error_if_condition_is_false___");
}

?>